 /**
  * CTA Mission Backend Server
  * 메인 엔트리 포인트
  */
 
 import dotenv from 'dotenv';
 // 환경변수 로드 (가장 먼저 실행)
 dotenv.config();
 
 import express, { Application } from 'express';
 import cors from 'cors';
 import helmet from 'helmet';
 import morgan from 'morgan';
 import { createServer } from 'http';
 import { Server as SocketIOServer } from 'socket.io';
 
 
 
 // 설정 및 유틸리티 import
 import { logger } from './utils/logger';
 import { errorHandler } from './middlewares/errorHandler';
 import { rateLimiter } from './middlewares/rateLimiter';
 import { connectDatabase } from './config/database';
 
 // 라우트 import (아직 생성되지 않음 - 추후 추가)
 // import { missionRoutes } from '@routes/mission.routes';
 // import { authRoutes } from '@routes/auth.routes';
 // import { gameRoutes } from '@routes/game.routes';
 // import { rankingRoutes } from '@routes/ranking.routes';
 
 // Express 앱 초기화
 const app: Application = express();
 const httpServer = createServer(app);
 
 // Socket.io 서버 초기화
 const io = new SocketIOServer(httpServer, {
   cors: {
     origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
     credentials: true,
   },
   path: process.env.SOCKET_IO_PATH || '/socket.io/',
 });
 
 // 포트 설정
 const PORT = parseInt(process.env.PORT || '5000', 10);
 
 /**
  * 미들웨어 설정
  */
 const setupMiddlewares = (): void => {
   // 보안 헤더 설정
   app.use(helmet());
 
   // CORS 설정
   app.use(cors({
     origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
     credentials: true,
     methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
     allowedHeaders: ['Content-Type', 'Authorization'],
   }));
 
   // 요청 로깅
   if (process.env.NODE_ENV === 'development') {
     app.use(morgan('dev'));
   } else {
     app.use(morgan('combined', {
       stream: { write: (message) => logger.info(message.trim()) }
     }));
   }
 
   // Body 파싱
   app.use(express.json({ limit: '10mb' }));
   app.use(express.urlencoded({ extended: true, limit: '10mb' }));
 
   // Rate limiting
   app.use('/api/', rateLimiter);
 };
 
 /**
  * 라우트 설정
  */
 const setupRoutes = (): void => {
   // Health check 엔드포인트
     app.get('/health', (_req, res) => {
     res.status(200).json({
       status: 'ok',
       timestamp: new Date().toISOString(),
       uptime: process.uptime(),
       environment: process.env.NODE_ENV,
     });
   });
 
   // API 버전 정보
     app.get('/api/v1', (_req, res) => {
     res.json({
       version: '1.0.0',
       name: 'CTA Mission API',
       description: '크립토 가격 예측 게임 및 미션 시스템 API',
     });
   });
 
   // 라우트 등록 (추후 파일 생성 후 주석 해제)
   // app.use('/api/v1/auth', authRoutes);
   // app.use('/api/v1/missions', missionRoutes);
   // app.use('/api/v1/game', gameRoutes);
   // app.use('/api/v1/ranking', rankingRoutes);
 
   // 404 핸들러
   app.use('*', (req, res) => {
     res.status(404).json({
       error: 'Not Found',
       message: `Cannot ${req.method} ${req.originalUrl}`,
     });
   });
 
   // 글로벌 에러 핸들러
   app.use(errorHandler);
 };
 
 /**
  * Socket.io 이벤트 설정
  */
 const setupSocketIO = (): void => {
   io.on('connection', (socket) => {
     logger.info(`New socket connection: ${socket.id}`);
 
     // 룸 참가 (게임 세션용)
     socket.on('join-room', (roomId: string) => {
       socket.join(roomId);
       logger.info(`Socket ${socket.id} joined room ${roomId}`);
     });
 
     // 룸 퇴장
     socket.on('leave-room', (roomId: string) => {
       socket.leave(roomId);
       logger.info(`Socket ${socket.id} left room ${roomId}`);
     });
 
     // 연결 해제
     socket.on('disconnect', () => {
       logger.info(`Socket disconnected: ${socket.id}`);
     });
 
     // 에러 처리
     socket.on('error', (error) => {
       logger.error(`Socket error: ${error}`);
     });
   });
 };
 
 /**
  * 서버 시작
  */
 const startServer = async (): Promise<void> => {
   try {
     // 데이터베이스 연결
     await connectDatabase();
     logger.info('Database connected successfully');
 
     // 미들웨어 설정
     setupMiddlewares();
     logger.info('Middlewares configured');
 
     // 라우트 설정
     setupRoutes();
     logger.info('Routes configured');
 
     // Socket.io 설정
     setupSocketIO();
     logger.info('Socket.io configured');
 
     // HTTP 서버 시작
     httpServer.listen(PORT, () => {
       logger.info(`
         🚀 Server is running!
         🌍 Environment: ${process.env.NODE_ENV}
         🔧 Port: ${PORT}
         📡 API: http://localhost:${PORT}/api/v1
         🏥 Health: http://localhost:${PORT}/health
         🔌 Socket.io: ws://localhost:${PORT}
       `);
     });
   } catch (error) {
     logger.error('Failed to start server:', error);
     process.exit(1);
   }
 };
 
 /**
  * Graceful shutdown
  */
 const gracefulShutdown = (): void => {
   logger.info('Received shutdown signal');
 
   httpServer.close(() => {
     logger.info('HTTP server closed');
     
     // Socket.io 연결 종료
     io.close(() => {
       logger.info('Socket.io server closed');
     });
 
     // 데이터베이스 연결 종료
     // TODO: 데이터베이스 연결 종료 로직 추가
 
     process.exit(0);
   });
 
   // 30초 후 강제 종료
   setTimeout(() => {
     logger.error('Force shutdown after 30s');
     process.exit(1);
   }, 30000);
 };
 
 // 프로세스 시그널 처리
 process.on('SIGTERM', gracefulShutdown);
 process.on('SIGINT', gracefulShutdown);
 
 // 처리되지 않은 Promise 거부 처리
 process.on('unhandledRejection', (reason, promise) => {
   logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
   // 개발 환경에서는 프로세스 종료하지 않음
   if (process.env.NODE_ENV === 'production') {
     gracefulShutdown();
   }
 });
 
 // 처리되지 않은 예외 처리
 process.on('uncaughtException', (error) => {
   logger.error('Uncaught Exception:', error);
   gracefulShutdown();
 });
 
 // 서버 시작
 startServer();
