/**
 * Rate Limiting 미들웨어
 * API 요청 제한을 통한 DDoS 공격 방지
 */

import rateLimit from 'express-rate-limit';
import { Request, Response } from 'express';
import { logger } from '../utils/logger';

/**
 * IP 기반 화이트리스트
 * 특정 IP는 rate limit 제외
 */
const whitelistedIPs = (process.env.RATE_LIMIT_WHITELIST?.split(',').filter(ip => ip) || []);

export const skipRateLimitForWhitelisted = (req: Request): boolean => {
  const clientIP = req.ip || '';
  return whitelistedIPs.includes(clientIP);
};

/**
 * Rate limit 도달 시 응답 메시지
 */
const rateLimitMessage = {
  error: {
    message: '너무 많은 요청을 보내셨습니다. 잠시 후 다시 시도해주세요.',
    code: 'RATE_LIMIT_EXCEEDED',
    statusCode: 429,
    timestamp: new Date().toISOString(),
  },
};

/**
 * Rate limit 도달 핸들러
 */
const rateLimitHandler = (req: Request, res: Response): void => {
  logger.warn('Rate limit exceeded', {
    ip: req.ip,
    path: req.path,
    method: req.method,
    userAgent: req.get('user-agent'),
  });

  res.status(429).json(rateLimitMessage);
};

/**
 * 기본 Rate Limiter
 * 전체 API에 적용
 */
export const rateLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15분
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'), // 최대 100 요청
  message: rateLimitMessage,
  handler: rateLimitHandler,
  standardHeaders: true, // `RateLimit-*` 헤더 추가
  legacyHeaders: false, // `X-RateLimit-*` 헤더 비활성화
  skipSuccessfulRequests: false,
  keyGenerator: (req: Request): string => {
    // IP 주소를 키로 사용
    return req.ip || 'unknown';
  },
  skip: skipRateLimitForWhitelisted,
});

/**
 * 엄격한 Rate Limiter
 * 인증 관련 엔드포인트에 적용
 */
export const strictRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15분
  max: 5, // 최대 5 요청
  message: {
    error: {
      message: '너무 많은 인증 시도가 있었습니다. 15분 후에 다시 시도해주세요.',
      code: 'AUTH_RATE_LIMIT_EXCEEDED',
      statusCode: 429,
      timestamp: new Date().toISOString(),
    },
  },
  handler: rateLimitHandler,
  skipSuccessfulRequests: true, // 성공한 요청은 카운트하지 않음
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipRateLimitForWhitelisted,
});

/**
 * 게임 액션 Rate Limiter
 * 게임 플레이 관련 엔드포인트에 적용
 */
export const gameActionRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1분
  max: 30, // 최대 30 액션
  message: {
    error: {
      message: '게임 액션이 너무 빠릅니다. 잠시 후 다시 시도해주세요.',
      code: 'GAME_ACTION_RATE_LIMIT_EXCEEDED',
      statusCode: 429,
      timestamp: new Date().toISOString(),
    },
  },
  handler: rateLimitHandler,
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipRateLimitForWhitelisted,
});

/**
 * 가격 API Rate Limiter
 * 실시간 가격 조회 엔드포인트에 적용
 */
export const priceApiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1분
  max: 60, // 최대 60 요청 (초당 1회)
  message: {
    error: {
      message: '가격 조회 요청이 너무 많습니다.',
      code: 'PRICE_API_RATE_LIMIT_EXCEEDED',
      statusCode: 429,
      timestamp: new Date().toISOString(),
    },
  },
  handler: rateLimitHandler,
  standardHeaders: true,
  legacyHeaders: false,
  skip: skipRateLimitForWhitelisted,
});

/**
 * 동적 Rate Limiter 생성 함수
 * 특정 엔드포인트에 대한 커스텀 rate limit 생성
 */
export const createRateLimiter = (options: {
  windowMs: number;
  max: number;
  message?: string;
  skipSuccessfulRequests?: boolean;
}) => {
  return rateLimit({
    windowMs: options.windowMs,
    max: options.max,
    message: {
      error: {
        message: options.message || '요청 한도를 초과했습니다.',
        code: 'CUSTOM_RATE_LIMIT_EXCEEDED',
        statusCode: 429,
        timestamp: new Date().toISOString(),
      },
    },
    handler: rateLimitHandler,
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: options.skipSuccessfulRequests || false,
  });
};



/**
 * Rate limit 정보 헤더 추가 미들웨어
 */
export const addRateLimitHeaders = (_req: Request, res: Response, next: () => void): void => {
  res.setHeader('X-RateLimit-Policy', 'default');
  res.setHeader('X-RateLimit-Window', process.env.RATE_LIMIT_WINDOW_MS || '900000');
  res.setHeader('X-RateLimit-Max', process.env.RATE_LIMIT_MAX_REQUESTS || '100');
  next();
};