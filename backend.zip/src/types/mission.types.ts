// src/types/mission.types.ts

/**
 * 미션 타입 정의
 */
export enum MissionType {
  WALLET_INSTALL = 'WALLET_INSTALL',
  HOMEPAGE_VISIT = 'HOMEPAGE_VISIT',
  GAME_PLAY = 'GAME_PLAY',
  DAILY_LOGIN = 'DAILY_LOGIN',
  SOCIAL_SHARE = 'SOCIAL_SHARE',
  REFERRAL = 'REFERRAL'
}

/**
 * 미션 상태 정의
 */
export enum MissionStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  COMPLETED = 'COMPLETED',
  EXPIRED = 'EXPIRED'
}

/**
 * 미션 카테고리 정의
 */
export enum MissionCategory {
  ONBOARDING = 'ONBOARDING',
  DAILY = 'DAILY',
  SPECIAL = 'SPECIAL',
  SOCIAL = 'SOCIAL'
}

/**
 * 미션 기본 인터페이스
 */
export interface IMission {
  id: string;
  type: MissionType;
  category: MissionCategory;
  title: string;
  description: string;
  points: number;
  iconUrl?: string;
  status: MissionStatus;
  startDate?: Date;
  endDate?: Date;
  maxCompletions?: number;
  requirements?: IMissionRequirement[];
  createdAt: Date;
  updatedAt: Date;
}

/**
 * 미션 요구사항 인터페이스
 */
export interface IMissionRequirement {
  type: string;
  value: any;
  description?: string;
}

/**
 * 사용자 미션 진행 상태 인터페이스
 */
export interface IUserMission {
  id: string;
  userId: string;
  missionId: string;
  status: UserMissionStatus;
  completedAt?: Date;
  completionCount: number;
  progress?: number;
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * 사용자 미션 상태
 */
export enum UserMissionStatus {
  NOT_STARTED = 'NOT_STARTED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED'
}

/**
 * 미션 생성 DTO
 */
export interface CreateMissionDto {
  type: MissionType;
  category: MissionCategory;
  title: string;
  description: string;
  points: number;
  iconUrl?: string;
  startDate?: Date;
  endDate?: Date;
  maxCompletions?: number;
  requirements?: IMissionRequirement[];
}

/**
 * 미션 업데이트 DTO
 */
export interface UpdateMissionDto {
  title?: string;
  description?: string;
  points?: number;
  iconUrl?: string;
  status?: MissionStatus;
  startDate?: Date;
  endDate?: Date;
  maxCompletions?: number;
  requirements?: IMissionRequirement[];
}

/**
 * 미션 검증 요청 DTO
 */
export interface VerifyMissionDto {
  missionId: string;
  userId: string;
  data?: Record<string, any>;
}

/**
 * 미션 검증 결과
 */
export interface MissionVerificationResult {
  success: boolean;
  message: string;
  pointsEarned?: number;
  completionCount?: number;
  metadata?: Record<string, any>;
}

/**
 * 미션 필터링 옵션
 */
export interface MissionFilterOptions {
  category?: MissionCategory;
  status?: MissionStatus;
  type?: MissionType;
  userId?: string;
  includeCompleted?: boolean;
  limit?: number;
  offset?: number;
}

/**
 * 페이지네이션된 미션 응답
 */
export interface PaginatedMissionsResponse {
  missions: IMission[];
  total: number;
  limit: number;
  offset: number;
  hasMore: boolean;
}

/**
 * 미션 통계
 */
export interface MissionStatistics {
  totalMissions: number;
  completedMissions: number;
  totalPointsEarned: number;
  completionRate: number;
  categoryBreakdown: Record<MissionCategory, number>;
}