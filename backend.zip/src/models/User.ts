// src/models/User.ts

import { 
  Entity, 
  PrimaryGeneratedColumn, 
  Column, 
  CreateDateColumn, 
  UpdateDateColumn,
  OneToMany,
  Index,
  BeforeInsert,
  BeforeUpdate
} from 'typeorm';

import { UserRole, UserStatus } from '../types/user.types';
import { UserMission } from './UserMission';
import { PointHistory } from './PointHistory';

/**
 * 사용자 엔티티
 */
@Entity('users')
@Index(['email', 'status'])
@Index(['username', 'status'])
@Index(['walletAddress'])
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'varchar',
    length: 255,
    nullable: true,
    unique: true
  })
  email?: string;

  @Column({
    type: 'varchar',
    length: 50,
    nullable: false,
    unique: true
  })
  @Index()
  username: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true
  })
  displayName?: string;

  @Column({
    type: 'varchar',
    length: 500,
    nullable: true
  })
  avatarUrl?: string;

  @Column({
    type: 'varchar',
    length: 42,
    nullable: true,
    unique: true
  })
  walletAddress?: string;

  @Column({
    type: 'enum',
    enum: UserRole,
    default: UserRole.USER
  })
  role: UserRole;

  @Column({
    type: 'enum',
    enum: UserStatus,
    default: UserStatus.ACTIVE
  })
  @Index()
  status: UserStatus;

  @Column({
    type: 'int',
    default: 0
  })
  totalPoints: number;

  @Column({
    type: 'timestamp',
    nullable: true
  })
  lastLoginAt?: Date;

  @Column({
    type: 'jsonb',
    nullable: true
  })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @OneToMany(() => UserMission, userMission => userMission.user)
  userMissions: UserMission[];

  @OneToMany(() => PointHistory, pointHistory => pointHistory.user)
  pointHistories: PointHistory[];

  /**
   * 포인트 추가
   */
  addPoints(points: number): void {
    this.totalPoints += points;
  }

  /**
   * 포인트 차감
   */
  deductPoints(points: number): boolean {
    if (this.totalPoints < points) {
      return false;
    }
    this.totalPoints -= points;
    return true;
  }

  /**
   * 사용자가 활성 상태인지 확인
   */
  isActive(): boolean {
    return this.status === UserStatus.ACTIVE;
  }

  /**
   * 관리자 권한 확인
   */
  isAdmin(): boolean {
    return this.role === UserRole.ADMIN;
  }

  /**
   * 모더레이터 이상 권한 확인
   */
  isModerator(): boolean {
    return this.role === UserRole.ADMIN || this.role === UserRole.MODERATOR;
  }

  /**
   * 지갑 연결 여부 확인
   */
  hasWallet(): boolean {
    return !!this.walletAddress;
  }

  /**
   * 사용자명 유효성 검증
   */
  @BeforeInsert()
  @BeforeUpdate()
  validateUsername(): void {
    if (this.username) {
      // 영문자, 숫자, 언더스코어만 허용
      const validUsername = /^[a-zA-Z0-9_]{3,30}$/.test(this.username);
      if (!validUsername) {
        throw new Error('Username must be 3-30 characters and contain only letters, numbers, and underscores');
      }
    }
  }

  /**
   * 이메일 형식 검증
   */
  @BeforeInsert()
  @BeforeUpdate()
  validateEmail(): void {
    if (this.email) {
      const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email);
      if (!validEmail) {
        throw new Error('Invalid email format');
      }
    }
  }

  /**
   * 지갑 주소 형식 검증
   */
  @BeforeInsert()
  @BeforeUpdate()
  validateWalletAddress(): void {
    if (this.walletAddress) {
      // Ethereum 주소 형식 검증 (0x로 시작하고 40자의 16진수)
      const validAddress = /^0x[a-fA-F0-9]{40}$/.test(this.walletAddress);
      if (!validAddress) {
        throw new Error('Invalid wallet address format');
      }
    }
  }
}