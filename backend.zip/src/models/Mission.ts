// src/models/Mission.ts

import { 
  Entity, 
  PrimaryGeneratedColumn, 
  Column, 
  CreateDateColumn, 
  UpdateDateColumn,
  OneToMany,
  Index
} from 'typeorm';

import { 
  MissionType, 
  MissionStatus, 
  MissionCategory,
  IMissionRequirement 
} from '../types/mission.types';
import { UserMission } from './UserMission';

/**
 * 미션 엔티티
 */
@Entity('missions')
@Index(['type', 'category', 'status'])
export class Mission {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'enum',
    enum: MissionType,
    nullable: false
  })
  @Index()
  type: MissionType;

  @Column({
    type: 'enum',
    enum: MissionCategory,
    nullable: false
  })
  @Index()
  category: MissionCategory;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: false
  })
  title: string;

  @Column({
    type: 'text',
    nullable: false
  })
  description: string;

  @Column({
    type: 'int',
    nullable: false,
    default: 0
  })
  points: number;

  @Column({
    type: 'varchar',
    length: 500,
    nullable: true
  })
  iconUrl?: string;

  @Column({
    type: 'enum',
    enum: MissionStatus,
    default: MissionStatus.ACTIVE
  })
  @Index()
  status: MissionStatus;

  @Column({
    type: 'timestamp',
    nullable: true
  })
  startDate?: Date;

  @Column({
    type: 'timestamp',
    nullable: true
  })
  endDate?: Date;

  @Column({
    type: 'int',
    nullable: true,
    default: 1
  })
  maxCompletions?: number;

  @Column({
    type: 'jsonb',
    nullable: true
  })
  requirements?: IMissionRequirement[];

  @Column({
    type: 'jsonb',
    nullable: true
  })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @OneToMany(() => UserMission, userMission => userMission.mission)
  userMissions: UserMission[];

  /**
   * 미션이 활성화되어 있는지 확인
   */
  isActive(): boolean {
    const now = new Date();
    
    if (this.status !== MissionStatus.ACTIVE) {
      return false;
    }

    if (this.startDate && now < this.startDate) {
      return false;
    }

    if (this.endDate && now > this.endDate) {
      return false;
    }

    return true;
  }

  /**
   * 미션이 만료되었는지 확인
   */
  isExpired(): boolean {
    if (!this.endDate) {
      return false;
    }

    return new Date() > this.endDate;
  }

  /**
   * 요구사항 검증
   */
  validateRequirements(data: Record<string, any>): boolean {
    if (!this.requirements || this.requirements.length === 0) {
      return true;
    }

    return this.requirements.every(req => {
      const value = data[req.type];
      
      switch (req.type) {
        case 'minLevel':
          return value >= req.value;
        case 'hasWallet':
          return !!value === req.value;
        case 'completedMission':
          return value === req.value;
        default:
          return value === req.value;
      }
    });
  }
}