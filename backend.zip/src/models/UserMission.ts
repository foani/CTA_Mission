// src/models/UserMission.ts

import { 
  Entity, 
  PrimaryGeneratedColumn, 
  Column, 
  CreateDateColumn, 
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  Unique
} from 'typeorm';

import { UserMissionStatus } from '../types/mission.types';
import { User } from './User';
import { Mission } from './Mission';

/**
 * 사용자 미션 진행 상태 엔티티
 */
@Entity('user_missions')
@Unique(['userId', 'missionId']) // 사용자당 미션 하나
@Index(['userId', 'status'])
@Index(['missionId', 'status'])
export class UserMission {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({
    type: 'uuid',
    nullable: false
  })
  userId: string;

  @Column({
    type: 'uuid',
    nullable: false
  })
  missionId: string;

  @Column({
    type: 'enum',
    enum: UserMissionStatus,
    default: UserMissionStatus.NOT_STARTED
  })
  @Index()
  status: UserMissionStatus;

  @Column({
    type: 'timestamp',
    nullable: true
  })
  completedAt?: Date;

  @Column({
    type: 'int',
    default: 0
  })
  completionCount: number;

  @Column({
    type: 'int',
    nullable: true,
    default: 0
  })
  progress?: number;

  @Column({
    type: 'jsonb',
    nullable: true
  })
  metadata?: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => User, user => user.userMissions, {
    onDelete: 'CASCADE'
  })
  @JoinColumn({ name: 'userId' })
  user: User;

  @ManyToOne(() => Mission, mission => mission.userMissions, {
    onDelete: 'CASCADE'
  })
  @JoinColumn({ name: 'missionId' })
  mission: Mission;

  /**
   * 미션 시작
   */
  start(): void {
    if (this.status === UserMissionStatus.NOT_STARTED) {
      this.status = UserMissionStatus.IN_PROGRESS;
    }
  }

  /**
   * 미션 완료
   */
  complete(): void {
    this.status = UserMissionStatus.COMPLETED;
    this.completedAt = new Date();
    this.completionCount += 1;
    this.progress = 100;
  }

  /**
   * 미션 실패 처리
   */
  fail(): void {
    this.status = UserMissionStatus.FAILED;
  }

  /**
   * 진행률 업데이트
   */
  updateProgress(progress: number): void {
    this.progress = Math.min(Math.max(0, progress), 100);
    
    if (this.progress === 100 && this.status !== UserMissionStatus.COMPLETED) {
      this.complete();
    } else if (this.progress > 0 && this.status === UserMissionStatus.NOT_STARTED) {
      this.start();
    }
  }

  /**
   * 재시도 가능 여부 확인
   */
  canRetry(maxCompletions?: number): boolean {
    if (!maxCompletions) {
      return true; // 제한 없음
    }

    return this.completionCount < maxCompletions;
  }

  /**
   * 미션 재시작
   */
  reset(): void {
    if (this.status === UserMissionStatus.COMPLETED || 
        this.status === UserMissionStatus.FAILED) {
      this.status = UserMissionStatus.NOT_STARTED;
      this.progress = 0;
      this.completedAt = undefined;
    }
  }
}