/**
 * PostgreSQL 데이터베이스 연결 설정
 * pg 라이브러리를 사용한 connection pool 관리
 */

import { Pool, PoolConfig, PoolClient } from 'pg';
import { logger } from '../utils/logger';

/**
 * 데이터베이스 설정
 */
const poolConfig: PoolConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME || 'cta_mission_db',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD,
  
  // Connection pool 설정
  max: 20, // 최대 연결 수
  idleTimeoutMillis: 30000, // 30초 idle timeout
  connectionTimeoutMillis: 2000, // 2초 연결 timeout
  
  // SSL 설정 (프로덕션 환경)
  ...(process.env.NODE_ENV === 'production' && {
    ssl: {
      rejectUnauthorized: false,
    },
  }),
};

/**
 * 데이터베이스 connection pool
 */
export const pool = new Pool(poolConfig);

/**
 * 데이터베이스 연결 테스트
 */
export const connectDatabase = async (): Promise<void> => {
  try {
    const client = await pool.connect();
    
    // 연결 테스트 쿼리
    const result = await client.query('SELECT NOW()');
    logger.info('Database connected successfully', {
      timestamp: result.rows[0].now,
      database: poolConfig.database,
      host: poolConfig.host,
    });
    
    client.release();
  } catch (error) {
    logger.error('Database connection failed:', error);
    throw error;
  }
};

/**
 * 데이터베이스 연결 종료
 */
export const disconnectDatabase = async (): Promise<void> => {
  try {
    await pool.end();
    logger.info('Database connection pool closed');
  } catch (error) {
    logger.error('Error closing database connection:', error);
    throw error;
  }
};

/**
 * 쿼리 실행 헬퍼 함수
 */
export const query = async <T = any>(
  text: string,
  params?: any[]
): Promise<T[]> => {
  const start = Date.now();
  
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    
    // 개발 환경에서는 쿼리 로깅
    if (process.env.NODE_ENV === 'development') {
      logger.debug('Database query executed', {
        query: text,
        params,
        duration: `${duration}ms`,
        rows: result.rowCount,
      });
    }
    
    return result.rows;
  } catch (error) {
    const duration = Date.now() - start;
    logger.error('Database query error', {
      query: text,
      params,
      duration: `${duration}ms`,
      error,
    });
    throw error;
  }
};

/**
 * 트랜잭션 헬퍼 함수
 */
export const transaction = async <T>(
  callback: (client: PoolClient) => Promise<T>
): Promise<T> => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

/**
 * 데이터베이스 상태 확인
 */
export const checkDatabaseHealth = async (): Promise<{
  isHealthy: boolean;
  activeConnections: number;
  idleConnections: number;
  totalConnections: number;
}> => {
  try {
    // 연결 테스트
    await pool.query('SELECT 1');
    
    return {
      isHealthy: true,
      activeConnections: pool.waitingCount,
      idleConnections: pool.idleCount,
      totalConnections: pool.totalCount,
    };
  } catch (error) {
    logger.error('Database health check failed:', error);
    return {
      isHealthy: false,
      activeConnections: 0,
      idleConnections: 0,
      totalConnections: 0,
    };
  }
};

/**
 * Pool 이벤트 리스너 설정
 */
pool.on('error', (err) => {
  logger.error('Unexpected database pool error', err);
});

pool.on('connect', () => {
  logger.debug('New database client connected');
});

pool.on('acquire', () => {
  logger.debug('Database client acquired from pool');
});

pool.on('remove', () => {
  logger.debug('Database client removed from pool');
});